from langchain_community.document_loaders.recursive_url_loader import (
    RecursiveUrlLoader,
    _metadata_extractor,
)

__all__ = ["_metadata_extractor", "RecursiveUrlLoader"]

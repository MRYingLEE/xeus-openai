from langchain_community.document_loaders.parsers.msword import MsWordParser

__all__ = ["MsWordParser"]

from langchain_community.document_loaders.generic import (
    DEFAULT,
    GenericLoader,
    _PathLike,
)

__all__ = ["_PathLike", "DEFAULT", "GenericLoader"]

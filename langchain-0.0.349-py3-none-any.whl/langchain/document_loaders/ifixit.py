from langchain_community.document_loaders.ifixit import IFIXIT_BASE_URL, IFixitLoader

__all__ = ["IFIXIT_BASE_URL", "IFixitLoader"]

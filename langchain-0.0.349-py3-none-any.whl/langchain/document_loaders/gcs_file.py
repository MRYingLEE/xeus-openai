from langchain_community.document_loaders.gcs_file import GCSFileLoader

__all__ = ["GCSFileLoader"]

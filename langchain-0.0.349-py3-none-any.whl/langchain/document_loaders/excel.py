from langchain_community.document_loaders.excel import UnstructuredExcelLoader

__all__ = ["UnstructuredExcelLoader"]

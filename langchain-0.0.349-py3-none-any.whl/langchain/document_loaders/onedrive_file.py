from langchain_community.document_loaders.onedrive_file import (
    CHUNK_SIZE,
    OneDriveFileLoader,
)

__all__ = ["CHUNK_SIZE", "OneDriveFileLoader"]
